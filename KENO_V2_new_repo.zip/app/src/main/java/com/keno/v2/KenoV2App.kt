package com.keno.v2

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

data class Vec2(val x: Float, val y: Float) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(s: Float) = Vec2(x * s, y * s)
    fun dot(o: Vec2) = x * o.x + y * o.y
    fun len(): Float = hypot(x, y)
    fun normalized(): Vec2 {
        val l = len()
        return if (l > 1e-5f) Vec2(x / l, y / l) else Vec2(0f, 0f)
    }
}

data class SpinInput(
    val horizontal: Float = 0f,
    val vertical: Float = 0f
)

data class CueStats(
    val name: String = "Standard",
    val level: Int = 1,
    val force: Float = 0.5f,
    val aim: Float = 0.5f,
    val spin: Float = 0.5f,
    val time: Float = 0.5f,
    val bonusForce: Float = 0f,
    val bonusAim: Float = 0f,
    val bonusSpin: Float = 0f,
    val bonusTime: Float = 0f
) {
    fun totalForce() = (force + bonusForce).coerceIn(0f, 1.5f)
    fun totalSpin() = (spin + bonusSpin).coerceIn(0f, 1.5f)
}

data class OverlayOptions(
    val showCueBallPath: Boolean = true,
    val showTargetBallPath: Boolean = true,
    val showOtherBallsPath: Boolean = true,
    val showRailBounces: Boolean = true,
    val showContactPoint: Boolean = true,
    val showFinalPositions: Boolean = true,
    val showAllPaths: Boolean = true,
    val extendFullTableRays: Boolean = true
)

class KenoPrefsStore(context: Context) {
    private val prefs = context.getSharedPreferences("keno_v2_prefs", Context.MODE_PRIVATE)

    fun saveOptions(o: OverlayOptions) {
        prefs.edit()
            .putBoolean("cuePath", o.showCueBallPath)
            .putBoolean("targetPath", o.showTargetBallPath)
            .putBoolean("otherPath", o.showOtherBallsPath)
            .putBoolean("bounces", o.showRailBounces)
            .putBoolean("contact", o.showContactPoint)
            .putBoolean("finals", o.showFinalPositions)
            .putBoolean("allPaths", o.showAllPaths)
            .putBoolean("fullRays", o.extendFullTableRays)
            .apply()
    }

    fun loadOptions(): OverlayOptions = OverlayOptions(
        showCueBallPath = prefs.getBoolean("cuePath", true),
        showTargetBallPath = prefs.getBoolean("targetPath", true),
        showOtherBallsPath = prefs.getBoolean("otherPath", true),
        showRailBounces = prefs.getBoolean("bounces", true),
        showContactPoint = prefs.getBoolean("contact", true),
        showFinalPositions = prefs.getBoolean("finals", true),
        showAllPaths = prefs.getBoolean("allPaths", true),
        extendFullTableRays = prefs.getBoolean("fullRays", true)
    )

    fun loadCue(): CueStats = CueStats(
        name = prefs.getString("cueName", "Standard") ?: "Standard",
        level = prefs.getInt("cueLevel", 1),
        force = prefs.getFloat("cueForce", 0.5f),
        aim = prefs.getFloat("cueAim", 0.5f),
        spin = prefs.getFloat("cueSpin", 0.5f),
        time = prefs.getFloat("cueTime", 0.5f),
        bonusForce = prefs.getFloat("bForce", 0f),
        bonusAim = prefs.getFloat("bAim", 0f),
        bonusSpin = prefs.getFloat("bSpin", 0f),
        bonusTime = prefs.getFloat("bTime", 0f)
    )
}

data class DetectedBall(
    val id: Int,
    val center: Vec2,
    val radius: Float,
    val isCueBall: Boolean
)

data class TableBounds(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val pockets: List<Vec2>,
    val pocketRadius: Float
)

data class FrameAnalysis(
    val table: TableBounds,
    val balls: List<DetectedBall>,
    val aimDir: Vec2,
    val powerFraction: Float?
)

class FrameVisionAnalyzer {

    fun analyze(frame: Bitmap, fallbackPower: Float): FrameAnalysis {
        val w = frame.width
        val h = frame.height

        val left = w * 0.175f
        val right = w * 0.825f
        val top = h * 0.175f
        val bottom = h * 0.825f

        val midX = (left + right) * 0.5f
        val pockets = listOf(
            Vec2(left, top),
            Vec2(midX, top),
            Vec2(right, top),
            Vec2(left, bottom),
            Vec2(midX, bottom),
            Vec2(right, bottom)
        )
        val tableW = right - left
        val pocketRadius = tableW * 0.032f
        val ballRadius = max(8f, tableW * 0.0145f)

        val table = TableBounds(left, top, right, bottom, pockets, pocketRadius)
        val balls = detectBalls(frame, table, ballRadius)
        val cueBall = balls.firstOrNull { it.isCueBall }
        val aimDir = detectAimDirection(frame, cueBall, balls, table)
        val detectedPower = detectPowerBar(frame) ?: fallbackPower

        return FrameAnalysis(table, balls, aimDir, detectedPower)
    }

    private fun detectBalls(
        bmp: Bitmap,
        table: TableBounds,
        defaultRadius: Float
    ): List<DetectedBall> {
        val w = bmp.width
        val h = bmp.height
        val step = max(2, (defaultRadius * 0.45f).toInt())

        val xStart = max(0, (table.left + defaultRadius).toInt())
        val xEnd = min(w - 1, (table.right - defaultRadius).toInt())
        val yStart = max(0, (table.top + defaultRadius).toInt())
        val yEnd = min(h - 1, (table.bottom - defaultRadius).toInt())

        val candidates = mutableListOf<Pair<Vec2, Boolean>>()

        var y = yStart
        while (y <= yEnd) {
            var x = xStart
            while (x <= xEnd) {
                val px = bmp.getPixel(x, y)
                val r = Color.red(px)
                val g = Color.green(px)
                val b = Color.blue(px)

                val isFelt = (b > r + 25 && b > g + 10 && r < 95)
                if (!isFelt) {
                    val isBrightCue = (r > 215 && g > 215 && b > 205)
                    val isBallLike = (max(r, max(g, b)) - min(r, min(g, b)) > 35) || isBrightCue
                    if (isBallLike) {
                        val pos = Vec2(x.toFloat(), y.toFloat())
                        if (candidates.none { (it.first - pos).len() < defaultRadius * 1.15f }) {
                            candidates.add(pos to isBrightCue)
                        }
                    }
                }
                x += step
            }
            y += step
        }

        val refined = candidates.map { (approx, cueHint) ->
            var sumX = 0f
            var sumY = 0f
            var count = 0
            val radInt = (defaultRadius * 0.8f).toInt()
            for (dy in -radInt..radInt step 2) {
                for (dx in -radInt..radInt step 2) {
                    val pxX = (approx.x + dx).toInt().coerceIn(0, w - 1)
                    val pxY = (approx.y + dy).toInt().coerceIn(0, h - 1)
                    val c = bmp.getPixel(pxX, pxY)
                    val lum = 0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)
                    if (lum > 110f) {
                        sumX += pxX
                        sumY += pxY
                        count++
                    }
                }
            }
            val center = if (count > 0) Vec2(sumX / count, sumY / count) else approx
            DetectedBall(0, center, defaultRadius, cueHint)
        }

        val cueIdx = refined.indices.maxByOrNull { idx ->
            val p = refined[idx].center
            val cx = p.x.toInt().coerceIn(0, w - 1)
            val cy = p.y.toInt().coerceIn(0, h - 1)
            val col = bmp.getPixel(cx, cy)
            Color.red(col) + Color.green(col) + Color.blue(col)
        } ?: -1

        return refined.mapIndexed { index, b ->
            b.copy(id = index + 1, isCueBall = index == cueIdx)
        }
    }

    private fun detectAimDirection(
        bmp: Bitmap,
        cueBall: DetectedBall?,
        balls: List<DetectedBall>,
        table: TableBounds
    ): Vec2 {
        val origin = cueBall?.center ?: Vec2((table.left + table.right) * 0.5f, (table.top + table.bottom) * 0.5f)
        var bestDir = Vec2(1f, 0f)
        var bestScore = -1f

        val steps = 360
        for (i in 0 until steps) {
            val angle = (i.toFloat() / steps) * (Math.PI.toFloat() * 2f)
            val dir = Vec2(cos(angle), sin(angle))
            var score = 0f
            var dist = cueBall?.radius?.plus(6f) ?: 20f
            val maxDist = hypot(table.right - table.left, table.bottom - table.top)

            while (dist < maxDist) {
                val px = (origin.x + dir.x * dist).toInt()
                val py = (origin.y + dir.y * dist).toInt()
                if (px < table.left.toInt() || px > table.right.toInt() ||
                    py < table.top.toInt() || py > table.bottom.toInt()
                ) break

                val col = bmp.getPixel(px, py)
                val r = Color.red(col)
                val g = Color.green(col)
                val b = Color.blue(col)
                if (r > 215 && g > 215 && b > 205) {
                    score += 1f
                }
                dist += 5f
            }

            if (score > bestScore) {
                bestScore = score
                bestDir = dir
            }
        }

        if (bestScore < 3f && cueBall != null) {
            val nearest = balls.filter { !it.isCueBall }.minByOrNull { (it.center - cueBall.center).len() }
            if (nearest != null) {
                bestDir = (nearest.center - cueBall.center).normalized()
            }
        }

        return bestDir
    }

    private fun detectPowerBar(bmp: Bitmap): Float? {
        val x = (bmp.width * 0.062f).toInt().coerceIn(0, bmp.width - 1)
        val topY = (bmp.height * 0.25f).toInt().coerceIn(0, bmp.height - 1)
        val botY = (bmp.height * 0.75f).toInt().coerceIn(0, bmp.height - 1)
        if (botY <= topY) return null

        var highestActiveY = botY
        for (y in botY downTo topY) {
            val col = bmp.getPixel(x, y)
            val r = Color.red(col)
            val g = Color.green(col)
            val b = Color.blue(col)
            if ((r > 130 || g > 130) && max(r, max(g, b)) - min(r, min(g, b)) > 45) {
                highestActiveY = y
            }
        }

        val span = (botY - topY).toFloat().coerceAtLeast(1f)
        val frac = ((botY - highestActiveY).toFloat() / span).coerceIn(0f, 1f)
        return if (frac > 0.02f) frac else null
    }
}

data class SimBall(
    val id: Int,
    val isCueBall: Boolean,
    var pos: Vec2,
    var vel: Vec2,
    val radius: Float,
    var spin: SpinInput = SpinInput(),
    var pocketed: Boolean = false,
    val trail: MutableList<Vec2> = mutableListOf()
)

data class BounceMark(val ballId: Int, val pos: Vec2)

data class ContactMark(
    val cueBallId: Int,
    val targetBallId: Int,
    val point: Vec2,
    val targetRayEnd: Vec2,
    val cueDeflectRayEnd: Vec2
)

data class SimResult(
    val balls: List<SimBall>,
    val bounces: List<BounceMark>,
    val contacts: List<ContactMark>,
    val firstTargetId: Int?
)

class FullPoolSimulator(private val table: TableBounds) {
    private val maxSpeed = 2400f
    private val rollingDecel = 360f
    private val railRestitution = 0.82f
    private val ballRestitution = 0.95f
    private val spinDeflect = 0.28f
    private val spinFollow = 0.22f
    private val minSpeed = 3f
    private val dt = 1f / 240f
    private val maxSteps = 14000

    fun simulate(
        detectedBalls: List<DetectedBall>,
        aimDir: Vec2,
        powerContinuous: Float,
        spin: SpinInput,
        cueStats: CueStats
    ): SimResult {
        val power01 = powerContinuous.coerceIn(0f, 1f)
        val forceScale = (0.72f + 0.28f * cueStats.totalForce()).coerceIn(0.5f, 1.4f)
        val spinScale = (0.50f + 0.50f * cueStats.totalSpin()).coerceIn(0.25f, 1.5f)

        val balls = detectedBalls.map { d ->
            SimBall(d.id, d.isCueBall, d.center, Vec2(0f, 0f), d.radius).apply { trail.add(pos) }
        }

        val cueBall = balls.firstOrNull { it.isCueBall }
            ?: return SimResult(balls, emptyList(), emptyList(), null)

        val dir = aimDir.normalized()
        cueBall.vel = dir * (power01 * forceScale * maxSpeed)
        cueBall.spin = SpinInput(
            horizontal = spin.horizontal.coerceIn(-1f, 1f) * spinScale,
            vertical = spin.vertical.coerceIn(-1f, 1f) * spinScale
        )

        val bounces = mutableListOf<BounceMark>()
        val contacts = mutableListOf<ContactMark>()
        val seenPairs = mutableSetOf<Long>()
        var firstTargetId: Int? = null

        repeat(maxSteps) {
            var anyMoving = false

            for (b in balls) {
                if (b.pocketed) continue
                val speed = b.vel.len()
                if (speed > minSpeed) {
                    anyMoving = true
                    val stepDir = b.vel.normalized()
                    val nextSpeed = max(0f, speed - rollingDecel * dt)
                    b.vel = stepDir * nextSpeed

                    if (b.isCueBall && abs(b.spin.vertical) > 1e-3f) {
                        val vSpinDelta = b.spin.vertical * spinFollow * speed * dt
                        b.vel = b.vel + stepDir * vSpinDelta
                        b.spin = b.spin.copy(vertical = b.spin.vertical * (1f - 1.4f * dt))
                    }

                    b.pos = b.pos + b.vel * dt
                    b.trail.add(b.pos)

                    if (isInPocket(b.pos)) {
                        b.pocketed = true
                        b.vel = Vec2(0f, 0f)
                        continue
                    }

                    var hitRail = false
                    if (b.pos.x - b.radius < table.left) {
                        b.pos = Vec2(table.left + b.radius, b.pos.y)
                        val spinY = b.spin.vertical * spinDeflect * abs(b.vel.x)
                        b.vel = Vec2(-b.vel.x * railRestitution, b.vel.y * railRestitution + spinY)
                        hitRail = true
                    } else if (b.pos.x + b.radius > table.right) {
                        b.pos = Vec2(table.right - b.radius, b.pos.y)
                        val spinY = -b.spin.vertical * spinDeflect * abs(b.vel.x)
                        b.vel = Vec2(-b.vel.x * railRestitution, b.vel.y * railRestitution + spinY)
                        hitRail = true
                    }

                    if (b.pos.y - b.radius < table.top) {
                        b.pos = Vec2(b.pos.x, table.top + b.radius)
                        val spinX = b.spin.horizontal * spinDeflect * abs(b.vel.y)
                        b.vel = Vec2(b.vel.x * railRestitution + spinX, -b.vel.y * railRestitution)
                        hitRail = true
                    } else if (b.pos.y + b.radius > table.bottom) {
                        b.pos = Vec2(b.pos.x, table.bottom - b.radius)
                        val spinX = -b.spin.horizontal * spinDeflect * abs(b.vel.y)
                        b.vel = Vec2(b.vel.x * railRestitution + spinX, -b.vel.y * railRestitution)
                        hitRail = true
                    }

                    if (hitRail) bounces.add(BounceMark(b.id, b.pos))
                } else {
                    b.vel = Vec2(0f, 0f)
                }
            }

            for (i in balls.indices) {
                val a = balls[i]
                if (a.pocketed) continue
                for (j in i + 1 until balls.size) {
                    val b = balls[j]
                    if (b.pocketed) continue

                    val delta = b.pos - a.pos
                    val dist = delta.len()
                    val minDist = a.radius + b.radius
                    if (dist > 1e-4f && dist < minDist) {
                        val normal = delta * (1f / dist)
                        val overlap = minDist - dist
                        a.pos = a.pos - normal * (overlap * 0.5f)
                        b.pos = b.pos + normal * (overlap * 0.5f)

                        val relVel = b.vel - a.vel
                        val vn = relVel.dot(normal)
                        if (vn < 0f) {
                            val impulse = normal * (-(1f + ballRestitution) * vn * 0.5f)
                            a.vel = a.vel - impulse
                            b.vel = b.vel + impulse

                            val pairKey = (min(a.id, b.id).toLong() shl 32) or (max(a.id, b.id).toLong() and 0xffffffffL)
                            if (seenPairs.add(pairKey) && (a.isCueBall || b.isCueBall)) {
                                val target = if (a.isCueBall) b else a
                                if (firstTargetId == null) firstTargetId = target.id
                                val contactPt = a.pos + normal * a.radius
                                val targetDir = (if (a.isCueBall) b.vel else a.vel).normalized()
                                val cueDir = cueBall.vel.normalized()

                                contacts.add(
                                    ContactMark(
                                        cueBallId = cueBall.id,
                                        targetBallId = target.id,
                                        point = contactPt,
                                        targetRayEnd = rayToRail(contactPt, targetDir, target.radius),
                                        cueDeflectRayEnd = rayToRail(cueBall.pos, cueDir, cueBall.radius)
                                    )
                                )
                            }
                        }
                    }
                }
            }

            if (!anyMoving) break
        }

        return SimResult(balls, bounces, contacts, firstTargetId)
    }

    private fun rayToRail(start: Vec2, dir: Vec2, radius: Float): Vec2 {
        val d = dir.normalized()
        if (d.len() < 1e-4f) return start
        var tMax = Float.POSITIVE_INFINITY

        if (d.x > 1e-4f) tMax = min(tMax, (table.right - radius - start.x) / d.x)
        if (d.x < -1e-4f) tMax = min(tMax, (table.left + radius - start.x) / d.x)
        if (d.y > 1e-4f) tMax = min(tMax, (table.bottom - radius - start.y) / d.y)
        if (d.y < -1e-4f) tMax = min(tMax, (table.top + radius - start.y) / d.y)

        if (!tMax.isFinite() || tMax < 0f) return start
        return start + d * tMax
    }

    private fun isInPocket(pos: Vec2): Boolean {
        for (p in table.pockets) {
            if ((pos - p).len() <= table.pocketRadius) return true
        }
        return false
    }
}

class OverlayCanvasView(context: Context) : View(context) {
    var options: OverlayOptions = OverlayOptions()
        set(value) { field = value; invalidate() }

    var simResult: SimResult? = null
        set(value) { field = value; invalidate() }

    private val cuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeWidth = 5f; style = Paint.Style.STROKE }
    private val targetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.YELLOW; strokeWidth = 5.5f; style = Paint.Style.STROKE }
    private val otherPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.CYAN; strokeWidth = 4f; style = Paint.Style.STROKE }
    private val fullRayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 230, 80); strokeWidth = 3.5f; style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(18f, 10f), 0f)
    }
    private val cueRayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 240, 255); strokeWidth = 3.5f; style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(18f, 10f), 0f)
    }
    private val bouncePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 130, 0); strokeWidth = 4f; style = Paint.Style.STROKE }
    private val contactPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED; style = Paint.Style.FILL }
    private val finalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GREEN; strokeWidth = 3.5f; style = Paint.Style.STROKE }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val res = simResult ?: return

        if (options.showAllPaths) {
            for (ball in res.balls) {
                if (ball.trail.size < 2) continue
                val allowed = when {
                    ball.isCueBall -> options.showCueBallPath
                    ball.id == res.firstTargetId -> options.showTargetBallPath
                    else -> options.showOtherBallsPath
                }
                if (!allowed) continue
                val paint = when {
                    ball.isCueBall -> cuePaint
                    ball.id == res.firstTargetId -> targetPaint
                    else -> otherPaint
                }
                val p = Path().apply {
                    moveTo(ball.trail.first().x, ball.trail.first().y)
                    for (i in 1 until ball.trail.size) lineTo(ball.trail[i].x, ball.trail[i].y)
                }
                canvas.drawPath(p, paint)
            }
        }

        if (options.extendFullTableRays) {
            for (c in res.contacts) {
                if (options.showTargetBallPath) canvas.drawLine(c.point.x, c.point.y, c.targetRayEnd.x, c.targetRayEnd.y, fullRayPaint)
                if (options.showCueBallPath) canvas.drawLine(c.point.x, c.point.y, c.cueDeflectRayEnd.x, c.cueDeflectRayEnd.y, cueRayPaint)
            }
        }

        if (options.showRailBounces) {
            for (b in res.bounces) canvas.drawCircle(b.pos.x, b.pos.y, 9f, bouncePaint)
        }
        if (options.showContactPoint) {
            for (c in res.contacts) canvas.drawCircle(c.point.x, c.point.y, 9f, contactPaint)
        }
        if (options.showFinalPositions) {
            for (ball in res.balls) {
                if (!ball.pocketed) canvas.drawCircle(ball.pos.x, ball.pos.y, ball.radius, finalPaint)
            }
        }
    }
}

class FloatingKenoController(
    private val context: Context,
    private val wm: WindowManager,
    private val canvasView: OverlayCanvasView,
    initialOptions: OverlayOptions,
    private val onOptionsChanged: (OverlayOptions) -> Unit,
    private val onPowerChanged: (Float) -> Unit
) {
    private var currentOptions = initialOptions
    private var panelView: View? = null

    private val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE
    }

    fun attachAll() {
        val drawParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(canvasView, drawParams)

        val kButton = TextView(context).apply {
            text = "K"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(220, 25, 118, 210))
                setStroke(3, Color.WHITE)
            }
        }

        val btnSize = (48 * context.resources.displayMetrics.density).toInt()
        val btnParams = WindowManager.LayoutParams(
            btnSize, btnSize, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 180
        }

        var downX = 0f; var downY = 0f; var initX = 0; var initY = 0; var moved = false
        @SuppressLint("ClickableViewAccessibility")
        kButton.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; initX = btnParams.x; initY = btnParams.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - downX).toInt(); val dy = (ev.rawY - downY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    btnParams.x = initX + dx; btnParams.y = initY + dy
                    wm.updateViewLayout(kButton, btnParams); true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                else -> false
            }
        }
        wm.addView(kButton, btnParams)
    }

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private fun togglePanel() {
        if (panelView != null) {
            wm.removeView(panelView)
            panelView = null
            return
        }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            background = GradientDrawable().apply {
                cornerRadius = 24f
                setColor(Color.argb(235, 20, 24, 32))
                setStroke(2, Color.rgb(80, 140, 220))
            }
        }

        fun addSwitch(label: String, checked: Boolean, setter: (OverlayOptions, Boolean) -> OverlayOptions) {
            val sw = Switch(context).apply {
                text = label; isChecked = checked; setTextColor(Color.WHITE)
                setOnCheckedChangeListener { _, isChecked ->
                    currentOptions = setter(currentOptions, isChecked)
                    canvasView.options = currentOptions
                    onOptionsChanged(currentOptions)
                }
            }
            container.addView(sw)
        }

        addSwitch("Putanja bijele kugle", currentOptions.showCueBallPath) { o, v -> o.copy(showCueBallPath = v) }
        addSwitch("Putanja ciljane kugle", currentOptions.showTargetBallPath) { o, v -> o.copy(showTargetBallPath = v) }
        addSwitch("Putanje ostalih kugli", currentOptions.showOtherBallsPath) { o, v -> o.copy(showOtherBallsPath = v) }
        addSwitch("Odbijanja od mantinela", currentOptions.showRailBounces) { o, v -> o.copy(showRailBounces = v) }
        addSwitch("Tačka kontakta", currentOptions.showContactPoint) { o, v -> o.copy(showContactPoint = v) }
        addSwitch("Konačne pozicije", currentOptions.showFinalPositions) { o, v -> o.copy(showFinalPositions = v) }
        addSwitch("Prikaz svih putanja", currentOptions.showAllPaths) { o, v -> o.copy(showAllPaths = v) }
        addSwitch("Linije skroz do mantinele", currentOptions.extendFullTableRays) { o, v -> o.copy(extendFullTableRays = v) }

        val powerLabel = TextView(context).apply { text = "Ručna snaga (0–100%): 50%"; setTextColor(Color.WHITE); setPadding(0, 12, 0, 4) }
        val powerSeek = SeekBar(context).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    powerLabel.text = "Ručna snaga (0–100%): $progress%"
                    onPowerChanged(progress / 100f)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        container.addView(powerLabel)
        container.addView(powerSeek)

        val scroll = ScrollView(context).apply { addView(container) }
        val panelParams = WindowManager.LayoutParams(
            (310 * context.resources.displayMetrics.density).toInt(),
            (context.resources.displayMetrics.heightPixels * 0.72f).toInt(),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 90; y = 180 }

        wm.addView(scroll, panelParams)
        panelView = scroll
    }
}

class KenoOverlayService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var mainHandler: Handler? = null

    private lateinit var prefsStore: KenoPrefsStore
    private lateinit var canvasView: OverlayCanvasView
    private var manualPower = 0.50f
    private var currentSpin = SpinInput()
    private var cueStats = CueStats()
    private val analyzer = FrameVisionAnalyzer()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        mainHandler = Handler(mainLooper)
        prefsStore = KenoPrefsStore(this)
        cueStats = prefsStore.loadCue()
        startForegroundNotification()

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        canvasView = OverlayCanvasView(this)
        val options = prefsStore.loadOptions()
        canvasView.options = options

        FloatingKenoController(
            context = this, wm = wm, canvasView = canvasView,
            initialOptions = options,
            onOptionsChanged = { prefsStore.saveOptions(it) },
            onPowerChanged = { manualPower = it }
        ).attachAll()

        workerThread = HandlerThread("KenoVisionThread").apply { start() }
        workerHandler = Handler(workerThread!!.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA) ?: return START_NOT_STICKY

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(resultCode, data) ?: return START_NOT_STICKY
        projection = mp

        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, workerHandler)
        setupVirtualDisplay(mp)
        return START_STICKY
    }

    private fun setupVirtualDisplay(mp: MediaProjection) {
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels; val h = metrics.heightPixels; val dpi = metrics.densityDpi

        imageReader?.close()
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        reader.setOnImageAvailableListener({ ir ->
            val img = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = img.planes[0]
                val bmp = Bitmap.createBitmap(plane.rowStride / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(plane.buffer)
                val cropped = Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
                if (cropped != bmp) bmp.recycle()

                val analysis = analyzer.analyze(cropped, manualPower)
                cropped.recycle()

                val sim = FullPoolSimulator(analysis.table).simulate(
                    detectedBalls = analysis.balls,
                    aimDir = analysis.aimDir,
                    powerContinuous = analysis.powerFraction ?: manualPower,
                    spin = currentSpin,
                    cueStats = cueStats
                )
                mainHandler?.post { canvasView.simResult = sim }
            } finally {
                img.close()
            }
        }, workerHandler)

        virtualDisplay?.release()
        virtualDisplay = mp.createVirtualDisplay(
            "KenoCapture", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, workerHandler
        )
    }

    private fun startForegroundNotification() {
        val channelId = "keno_v2_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "KENO V2 Overlay", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val notif: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("KENO V2 aktivan")
            .setContentText("Analiza stola i simulacija putanja u toku")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        startForeground(1002, notif)
    }

    override fun onDestroy() {
        super.onDestroy()
        virtualDisplay?.release()
        projection?.stop()
        imageReader?.close()
        workerThread?.quitSafely()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var statusText: TextView

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK && res.data != null) {
            val svcIntent = Intent(this, KenoOverlayService::class.java).apply {
                putExtra(KenoOverlayService.EXTRA_RESULT_CODE, res.resultCode)
                putExtra(KenoOverlayService.EXTRA_DATA, res.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svcIntent)
            else startService(svcIntent)
            statusText.text = "Overlay pokrenut. Prebaci se na 8 Ball Pool."
        } else {
            statusText.text = "Snimanje ekrana nije odobreno."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }
        statusText = TextView(this).apply { text = "KENO V2 — spreman za pokretanje"; textSize = 16f }
        val btnStart = Button(this).apply {
            text = "Dozvoli overlay i pokreni KENO"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    return@setOnClickListener
                }
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            }
        }
        root.addView(statusText)
        root.addView(btnStart)
        setContentView(root)
    }
}
